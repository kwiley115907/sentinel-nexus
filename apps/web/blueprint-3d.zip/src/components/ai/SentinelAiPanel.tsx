"use client";

import { useState } from "react";

type Props = {
  title?: string;
  blueprint: unknown;
  onRoomsGenerated?: (rooms: any[], fullResponse?: any, prompt?: string) => void;
  onDevicesGenerated?: (devices: any[]) => void;
};

const quickPrompts = [
  "Create a 2 story school with classrooms, bathrooms, office, cafeteria, gym, stairs, doors, and windows",
  "Create a hospital with ER, exam rooms, nurse station, bathrooms, stairs, doors, and windows",
  "Add stairs and second floor access",
  "Place fire alarm devices: smoke detectors, pull stations, horn strobes, and control panel",
  "Review this blueprint for fire alarm coverage",
  "Create material takeoff for devices, wire, backboxes, and panels",
];

export default function SentinelAiPanel({
  title = "Sentinel Nexus AI",
  blueprint,
  onRoomsGenerated,
  onDevicesGenerated,
}: Props) {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function send(requestType: string, customPrompt = prompt) {
    setLoading(true);
    setResult("Sentinel AI is working...");

    try {
      const response = await fetch("/api/ai/gateway", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requestType, prompt: customPrompt, blueprint }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "AI request failed.");
      }

      if (Array.isArray(data.rooms)) onRoomsGenerated?.(data.rooms, data, customPrompt);
      if (Array.isArray(data.devices)) onDevicesGenerated?.(data.devices);

      setResult(JSON.stringify(data, null, 2));
    } catch (error) {
      setResult(error instanceof Error ? error.message : "AI failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-[2rem] border border-yellow-400/30 bg-black/20 p-4 backdrop-blur-sm">
      <h2 className="text-xl font-black text-yellow-300">{title}</h2>

      <textarea
        value={prompt}
        onChange={(event) => setPrompt(event.target.value)}
        placeholder="Example: Create a 2 story school with rooms, stairs, doors, windows, and fire alarm devices."
        className="mt-3 min-h-24 w-full rounded-xl bg-black/30 p-3 text-yellow-100"
      />

      <div className="mt-3 grid gap-2">
        {quickPrompts.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setPrompt(item)}
            className="rounded-xl bg-black/30 p-2 text-left text-xs font-bold text-yellow-100"
          >
            {item}
          </button>
        ))}
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <button onClick={() => send("blueprint-generator")} className="rounded-xl bg-yellow-400 p-2 text-xs font-black text-black">
          Generate Building
        </button>
        <button onClick={() => send("device-placement")} className="rounded-xl bg-green-700 p-2 text-xs font-black text-white">
          Place Devices
        </button>
        <button onClick={() => send("blueprint-review")} className="rounded-xl bg-blue-700 p-2 text-xs font-black text-white">
          Review
        </button>
        <button onClick={() => send("fire-code")} className="rounded-xl bg-red-700 p-2 text-xs font-black text-white">
          Fire Code
        </button>
        <button onClick={() => send("material-estimate")} className="col-span-2 rounded-xl bg-purple-700 p-2 text-xs font-black text-white">
          Estimate Materials
        </button>
      </div>

      <pre className="mt-3 max-h-60 overflow-auto rounded-xl bg-black/40 p-3 text-xs text-yellow-100">
        {loading ? "Loading..." : result}
      </pre>
    </section>
  );
}

"use client";

import * as THREE from "three";
import { Text } from "@react-three/drei";

export type ExteriorWallFootprint = {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  stories: number;
};

function formatFeetInches(value: number) {
  const totalInches = Math.round(Math.abs(value) * 12);
  const feet = Math.floor(totalInches / 12);
  const inches = totalInches % 12;
  return `${feet}'-${inches}"`;
}

function ShellWall({
  x,
  z,
  width,
  depth,
  height,
  label,
  selected,
}: {
  x: number;
  z: number;
  width: number;
  depth: number;
  height: number;
  label: string;
  selected?: boolean;
}) {
  const length = Math.max(width, depth);

  return (
    <group>
      <mesh position={[x, height / 2, z]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#cdba97" roughness={0.85} metalness={0.02} />
      </mesh>

      <lineSegments position={[x, height / 2, z]}>
        <edgesGeometry args={[new THREE.BoxGeometry(width, height, depth)]} />
        <lineBasicMaterial color={selected ? "#22c55e" : "#5c5344"} transparent opacity={selected ? 1 : 0.35} />
      </lineSegments>

      <Text position={[x, height + 0.45, z]} fontSize={0.28} color="#fde047">
        {label} {formatFeetInches(length)}
      </Text>
    </group>
  );
}

function RoofCap({
  centerX,
  centerZ,
  width,
  depth,
  y,
}: {
  centerX: number;
  centerZ: number;
  width: number;
  depth: number;
  y: number;
}) {
  const overhang = 0.4;
  const capW = width + overhang;
  const capD = depth + overhang;

  return (
    <group>
      <mesh position={[centerX, y + 0.06, centerZ]}>
        <boxGeometry args={[capW, 0.12, capD]} />
        <meshStandardMaterial color="#2a2f3a" roughness={0.7} />
      </mesh>

      {[
        { pos: [centerX, y + 0.2, centerZ - capD / 2 + 0.06] as [number, number, number], size: [capW, 0.22, 0.12] as [number, number, number] },
        { pos: [centerX, y + 0.2, centerZ + capD / 2 - 0.06] as [number, number, number], size: [capW, 0.22, 0.12] as [number, number, number] },
        { pos: [centerX - capW / 2 + 0.06, y + 0.2, centerZ] as [number, number, number], size: [0.12, 0.22, capD] as [number, number, number] },
        { pos: [centerX + capW / 2 - 0.06, y + 0.2, centerZ] as [number, number, number], size: [0.12, 0.22, capD] as [number, number, number] },
      ].map((p, i) => (
        <mesh key={i} position={p.pos}>
          <boxGeometry args={p.size} />
          <meshStandardMaterial color="#3a4150" roughness={0.75} />
        </mesh>
      ))}
    </group>
  );
}

export default function ExteriorWallRenderer({
  footprint,
  selected = false,
}: {
  footprint: ExteriorWallFootprint;
  selected?: boolean;
}) {
  const wallThickness = selected ? 0.45 : 0.32;
  const totalHeight = footprint.height * Math.max(1, footprint.stories);

  const centerX = (footprint.minX + footprint.maxX) / 2;
  const centerZ = (footprint.minZ + footprint.maxZ) / 2;
  const width = footprint.maxX - footprint.minX;
  const depth = footprint.maxZ - footprint.minZ;

  return (
    <group>
      <mesh position={[centerX, 0.025, centerZ]}>
        <boxGeometry args={[width, 0.05, depth]} />
        <meshStandardMaterial color="#3f4451" roughness={0.95} />
      </mesh>

      <ShellWall x={centerX} z={footprint.minZ} width={width} depth={wallThickness} height={totalHeight} label="North Exterior" selected={selected} />
      <ShellWall x={centerX} z={footprint.maxZ} width={width} depth={wallThickness} height={totalHeight} label="South Exterior" selected={selected} />
      <ShellWall x={footprint.minX} z={centerZ} width={wallThickness} depth={depth} height={totalHeight} label="West Exterior" selected={selected} />
      <ShellWall x={footprint.maxX} z={centerZ} width={wallThickness} depth={depth} height={totalHeight} label="East Exterior" selected={selected} />

      {Array.from({ length: Math.max(0, footprint.stories - 1) }).map((_, floor) => (
        <mesh key={floor} position={[centerX, footprint.height * (floor + 1), centerZ]}>
          <boxGeometry args={[width + 0.02, 0.06, depth + 0.02]} />
          <meshStandardMaterial color="#8f7d5c" roughness={0.9} />
        </mesh>
      ))}

      {footprint.showRoof !== false && (
        <RoofCap centerX={centerX} centerZ={centerZ} width={width} depth={depth} y={totalHeight} />
      )}

      <Text position={[centerX, totalHeight + 1.1, centerZ]} fontSize={0.4} color="#22c55e">
        Building Shell — {footprint.stories}F
      </Text>
    </group>
  );
}

export function getExteriorFootprintFromRooms(
  rooms: Array<{
    x: number;
    z: number;
    width: number;
    depth: number;
    height: number;
    stories: number;
  }>,
  padding = 2,
): ExteriorWallFootprint | null {
  const realRooms = rooms.filter((room) => !String((room as any).id || "").includes("exterior-shell"));
  if (!realRooms.length) return null;

  return {
    minX: Math.min(...realRooms.map((room) => room.x - room.width / 2)) - padding,
    maxX: Math.max(...realRooms.map((room) => room.x + room.width / 2)) + padding,
    minZ: Math.min(...realRooms.map((room) => room.z - room.depth / 2)) - padding,
    maxZ: Math.max(...realRooms.map((room) => room.z + room.depth / 2)) + padding,
    height: Math.max(...realRooms.map((room) => room.height || 3)),
    stories: Math.max(...realRooms.map((room) => room.stories || 1)),
  };
}
